//programmer authour:Waiyat Hamdani
//test or example chapter number one project
package test1waiyat;

public class Test1Waiyat {

    
    public static void main(String[] args) {
        System.out.println("Celsius 35 is Fahrenheit degree ");
    System.out.println((9 / 5) * 35 + 32);

    System.out.println("Correction: ");
    System.out.println((9.0 / 5) * 35 + 32);
  }
}


// Correct formulas:  °C x 9/5 + 32 = °F
//                   (°F - 32) x 5/9 = °C

    }
    
}
