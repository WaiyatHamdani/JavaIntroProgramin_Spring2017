/********************************************************************************
/********************************************************************************
 * Program Name:          TestChapter03 
 * Program Description:   Testing chapter 2
 *
 * Program Author:        Waiyat Hamdani
 * Date Created:          09/23/2015
 * Change#        Change Date      Programmer Name        Description
 * -------        ------------     -------------------    -------------------
********************************************************************************/
package test2waiyat;
import java.util.Scanner;
public class Test2Waiyat {

    public static void main(String[] args) {
         System.out.println("Enter an interger value for i:");
      Scanner input = new Scanner(System.in);
      int i = input.nextInt();      
      System.out.println("i= " + i);
              
      
      double total = 10;
      int sum = 0;
      sum++;
      total += total;
      System.out.println("Total: " + total);
      System.out.println("Sum: " + sum);

      int i = 10;
      int newNum = 10 * i++;
      System.out.println("i: " + i);
      System.out.println("newNum: " + newNum);

      i = 10;
      newNum = 10 * ++i;
      System.out.println("i: " + i);
      System.out.println("newNum: " + newNum);
      
      
      byte i = 100;
      long k = i * 3 + 4;  // k = 304
      double d = i * 3.1 + k / 2;  // d = 310 + 152 = 462
      System.out.println("i: " + i);
      System.out.println("k: " + k);
      System.out.println("d: " + d);
      
      
      double d = 3;
      float f = 3;      
      long l = 3;
      int i = 3;
      
      System.out.println("d: " + d);
      System.out.println("f: " + f);
      System.out.println("l: " + l);
      System.out.println("i: " + i);
     
      int i = (int) 3.0;
      int j = (int) 3.9;
      
      System.out.println("i: " + i);
      System.out.println("j: " + j);
     
      //int x = 5/2.0;  // incompatible types
      //int x = (int) 5/2.0;  // incompatible types
      int x = (int) (5/2.0);  // incompatible types
      
      System.out.println("x: " + x);
    }
    
}
