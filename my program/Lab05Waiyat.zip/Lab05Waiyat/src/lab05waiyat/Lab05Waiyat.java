/******************************************************************************
 * Program Name:          Lab05 - computing Pie
 * Program Description:  
 *  π  Value	=	3	3.1666666667	3.13333333333	3.14523809524	3.13968253968	Greater than or equal to 3.14 and less than 3.15
    t	=		+	4/(2*3*4)	-	4/(4*5*6)	+	4/(6*7*8)	-	4/(8*9*10)	+	4/((2i)*(2*i+1)*(2*i+2))
    i	=	0	1	2	3	4	i

 * Program Author:        Waiyat Hamdani
 * Date Created:         10/06/2016
 * Change#        Change Date      Programmer Name        Description
 * -------        ------------     -------------------    ---------------------
******************************************************************************/

package lab05waiyat;
import java.util.Scanner;
public class Lab05Waiyat {
    public static void main(String[] args) {  
     Scanner input = new Scanner(System.in);   
    //1st part
       double Pie = 3, savePie = 0,term = 0;
       int saveI= 0,sign = 1;
       boolean isRangeFound = false;
       
       //true
       for (int i= 1; i <= 1000;i++){
       term = ((double)sign*4.0)/((2.0*(double)i)*(2.0*(double)i+1.0)*(2.0*(double)i+2.0));
       Pie = Pie+term;
       sign= -1 * sign;
       
       //false
       if (isRangeFound==false && Pie >=3.14159265 && Pie <3.14159266){
       savePie = Pie;
       saveI = i;
       isRangeFound = true;
       }
       
       // \u03c0is api symbol
       if(i == 200 || i == 500 || i == 1000){
       System.out.printf("\nThe value of\u03c0 is:%.10f when i =%d",Pie,i); 
       }
       
       }  
       //output 
    System.out.printf("\nThe number of iterations to get to 3.14159265 is %d. \u03c0 = %.10f",saveI,savePie);
    }
    
}
