/******************************************************************************
 * Program Name:          In Class 05A
 * Program Description:   Enter an integer between 1 and 9
 * Program Author:        Waiyat Hamdani
 * Date Created:          10/13/2016
 * Change#        Change Date      Programmer Name        Description
 * -------        ------------     -------------------    ---------------------
******************************************************************************/
package inclass5awaiyat;
import java.util.Scanner;//import for scanner
public class Inclass5AWaiyat {

    public static void main(String[] args) {
       //Input
    Scanner input=new Scanner(System.in);
    int i,n,j,t=0,sum=0;
    System.out.println("Enter an integer between 1 and 9 ,inclusive:");
    n=input.nextInt();
    
    //max count 1< or >9
    while(n<1 || n>9)
    {
        System.out.println("incorrect.Enter an integer between 1 and 9 ,inclusive:");
        n=input.nextInt();
    }
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=i;j++)
        {
//count no of integers
            System.out.print(i);
            t++;
//sum of all integers
            sum=sum+i;//sum of all integers
        }
        System.out.println("\n");
    }
    System.out.println("The total number of integer written:\t"+t);
    System.out.println("The total sum of integers:\t"+sum);


    }
    
}
