/******************************************************************************
 * Program Name:          Inclass02 
 * Program Description:   This program calculates the volumes of two different 
 * sized cylinders and then reports the difference in volumes as a positive number. 
 *                        
 * Program Author:        Waiyat Hamdani
 * Date Created:          09/14/2016
 *
 * Change#        Change Date      Programmer Name        Description
 * -------        ------------     -------------------    ---------------------
 *****************************************************************************

package waiyatinclass02;

/**
 *
 * @author 01659956
 */
public class WaiyatInclass02 {

    public static void main(String[] args) {
     double radius; // Declare radius
    double area; // Declare area
    
    // Prompt the user to enter a radius
    System.out.print("Enter a number for radius : ");
    double radius = input.nextDouble();
    double height= input.nextDouble();
    
    // Compute volume
    double radius =  Double.parseDouble(JOptionPane.showInputDialog(null,"enter radius"));
    double volume= 3.14159*radius*radius * lenght;
    // Display result
    System.out.println("The volume for cylinder " +
      "is"+ "volume"+ volume);
  } 

    }
    

