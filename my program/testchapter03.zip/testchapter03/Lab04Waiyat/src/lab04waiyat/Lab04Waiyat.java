/******************************************************************************
 * Program Name:          Lab04 - Paystub Calculations
 * Program Description:   This program calculates net paycheck information
 * Program Author:        Kerry V. Cramer
 * Date Created:          02/10/2016
 * Change#        Change Date      Programmer Name        Description
 * -------        ------------     -------------------    ---------------------
******************************************************************************/

package lab04waiyat;
import java.util.Scanner;
public class Lab04Waiyat {

    public static void main(String[] args) {
      Scanner input = new Scanner(System.in);
      //All final Double
      final double SOC_SEC_RATE=0.06;
      final double MEDICARE_RATE=0.01;
      final double UNION_DUE_RATE= 0.02;
      final double RETIREMENT_HEALTH_RATE=0.03;
      
    //Input  
    System.out.println("Enter Hours Worked:");
    double hourWorked= input.nextDouble();
    System.out.println("Enter Pay Rate:");
    double payRate= input.nextDouble();
    System.out.println("Enter Federal Tax witholding rate:");
    double fedTaxWitholding=input.nextDouble();
    System.out.println("enter State witholding rate:");
    double stateTaxWitholding=input.nextDouble(); 
    System.out.println("Enter Gross Pay rate:");
    double grossPay =input.nextDouble();
    
    //Part Input Calculation
    System.out.println("GrossPay:"+(grossPay
             
    }
    
}
