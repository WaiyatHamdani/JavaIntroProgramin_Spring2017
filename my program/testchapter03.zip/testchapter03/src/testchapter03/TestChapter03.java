/********************************************************************************
/********************************************************************************
 * Program Name:          TestChapter03 
 * Program Description:   Testing chapter 3
 *
 * Program Author:        Waiyat Hamdani
 * Date Created:          09/23/2015
 * Change#        Change Date      Programmer Name        Description
 * -------        ------------     -------------------    -------------------
********************************************************************************/
package testchapter03;
import java.util.Scanner;
public class TestChapter03 {
  public static void main(String[] args) {
      
      System.out.println("Enter an interger value for i:");
      Scanner input = new Scanner(System.in);
      int i = input.nextInt();      
      System.out.println("i= " + i);
   
      
      boolean b = (1 > 2);
      System.out.println("b = " + b);
       
      int radius = 0;
      if (radius > 0) {   
        double area = radius * radius * 3.14159;
        System.out.println("The area for the "  
          + "circle of radius " + radius + 
          " is " + area);
      }
      else {
        System.out.println("Zero or Negative input");        
      }
     
      double score = 99;
      if (score >= 90.0)
        System.out.print("A");
      else if (score >= 80.0)
        System.out.print("B");
      else if (score >= 70.0)
        System.out.print("C");
      else if (score >= 60.0)
        System.out.print("D");
      else if (score >= 60.0)
        System.out.print("D");
      else
        System.out.print("F");
      
      int i = 1, j = 2, k = 3;
      if (i > j)
        if (i > k)
          System.out.println("A");
        else
          System.out.println("B");
      
      int i = 1; 
      int j = 2;
      int k = 3;
      if (i > j) 
        if (i > k)
        System.out.println("A");
        else; 
      else 
        System.out.println("B");
      
      
      double radius = -10;
      double area = 0;
      if (radius >= 0);
      {
        area = radius*radius*Math.PI;
        System.out.println(
          "The area for the circle of radius " +
          radius + " is " + area);
      }
     
      
      int number = 11;
      boolean even = false;       
      if (number % 2 == 0)
        even = true;
      else
        even = false;
      System.out.println("even = " + even);
      
       
      int number = 13;
      boolean even = number % 2 == 0;   
      System.out.println("even = " + even);
      
      
      boolean even = true;
      if (even == true)
          System.out.println("It is even.");
      if (even)
          System.out.println("It is even.");        
      
      int number = 12;            
      System.out.println("Is " + number + " divisible by 2 and 3? " +
        ((number % 2 == 0) && (number % 3 == 0)));
      
      System.out.println("Is " + number + " divisible by 2 or 3? " +
        ((number % 2 == 0) || (number % 3 == 0)));

      System.out.println("Is " + number + 
        " divisible by 2 or 3, but not both? " +
        ((number % 2 == 0) ^ (number % 3 == 0))); 
     
      
      int day = 4;
      switch (day) {
        case 0: System.out.println("Sun"); break;  
        case 1: System.out.println("Mon"); break;
        case 2: System.out.println("Tue"); break;
        case 3: System.out.println("Wed"); break;
        case 4: System.out.println("Thu"); break;
        case 5: System.out.println("Fri"); break;       
        case 6: System.out.println("Sat"); break;
      }  

     
     
  }
              
}
