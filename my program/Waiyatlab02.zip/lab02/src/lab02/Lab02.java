/******************************************************************************
 * Program Name:          lab02 
 * Program Description:   Java program that calculates and displays a restaurant bill
 *                        
 * Program Author:        Waiyat Hamdani
 * Date Created:          9/19/2016
 *
 * Change#        Change Date      Programmer Name        Description
 * -------        ------------     -------------------    ---------------------
 ******************************************************************************/

package lab02;
import java.util.Scanner;
public class Lab02 {

    public static void main(String[] args) {
        Scanner input =new Scanner(System.in);
        final double LOW_TIP_RATE = 0.10;
        final double MED_TIP_RATE = 0.15;
        final double HIGH_TIP_RATE = 0.20;
        final double CT_TAX_RATE = 0.0635;
        System.out.println("Enter the price of your appetizer");
        double appetizerprice = input.nextDouble();
        System.out.println("Enter the price of your dinner");
        double dinnerprice = input.nextDouble();
        System.out.println("Enter the price of your dessert");
        double dessertprice = input.nextDouble();
        
        System.out.println("appetizer price:$"+appetizerprice);
        System.out.println("dinner price:$"+dinnerprice);
        System.out.println("dessert price:$"+dessertprice);
        System.out.println("Total bill:$"+Math.abs(appetizerprice+dinnerprice+dessertprice+CT_TAX_RATE));
        System.out.println("tax price:$"+ (CT_TAX_RATE*100)/100.0);
        System.out.println("/n");
        System.out.println("Enter Tip Recomendation");
        System.out.println("Low tip(10%):$"+(LOW_TIP_RATE*100)/100.0);
        System.out.println("Meddium tip(15%):$"+(MED_TIP_RATE*100)/100.0);
        System.out.println("High tip(20%):$"+(HIGH_TIP_RATE*100)/100.0);
        System.out.println("Low tip(10%):$" +LOW_TIP_RATE );
        System.out.println("Meddium tip(15%):$" + MED_TIP_RATE);
        System.out.println("High tip(20%):$" + HIGH_TIP_RATE);
    }
    
}