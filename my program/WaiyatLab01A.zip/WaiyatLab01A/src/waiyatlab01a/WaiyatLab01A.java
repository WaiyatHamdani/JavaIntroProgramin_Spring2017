/********************************************************************************
 * Program Name:          Lab01A – Temperature Farenheit to Celcius 
 * Program Description:Converting temperatures from Fahrenheit to Celsius and vice versa
 * Program Author:        Waiyat Hamdani
 * Date Created:          09/12/2016
 * Change#        Change Date      Programmer Name        Description
 * -------        ------------     -------------------    -------------------
********************************************************************************/

package waiyatlab01a;
public class WaiyatLab01A {

    public static void main(String[] args) {
    System.out.println("today temperature is 90 degrees Farenheit.in Celsius it is:"+(90-32)*5/9.0);
System.out.println("today temperature is 95 degrees Farenheit.in Celsius it is:"+(95-32)*5/9.0);
System.out.println("today temperature is 85 degrees Farenheit.in Celsius it is:"+(85-32)*5/9.0);
System.out.println("today temperature is 65 degrees Farenheit.in Celsius it is:"+(65-32)*5/9.0);
System.out.println("today temperature is 0 degrees Farenheit.in Celsius it is:"+(0-32)*5/9.0);
System.out.println(".................................................................................");
System.out.println("today temperature is 100 degrees Celcius.in Farenheit it is:"+(100*9/5.0+32));
System.out.println("today temperature is 45 degrees Celcius.in Farenheit it is:"+(45*9/5.0+32));
System.out.println("today temperature is 35 degrees Celcius.in Farenheit it is:"+(35*9/5.0+32));
System.out.println("today temperature is 0 degrees Celcius.in Farenheit it is:"+(0*9/5.0+32));

    }
    
}
