/******************************************************************************
 * Program Name:          Lab03
 * Program Description:   Sorting three odd/ even integers using If statement and logical operator only
 *                        
 * Program Author:        Waiyat Hamdani
 * Date Created:          9/25/2016
 *
 * Change#        Change Date      Programmer Name        Description
 * -------        ------------     -------------------    ---------------------
 ******************************************************************************/

package waiyatlab3;
import java.util.Scanner;
public class WaiyatLab3 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int Input1,Input2,Integer1,Integer2,Integer3, Min, Max, Hold, Sum, Product; 
        
        System.out.print("Please enter an integer between 0-99: ");
        Input1 = input.nextInt();
        if (Input1 > 99 || Input1 < 0) { 
        System.out.print("Outside Range. Please enter an integer between 0-99: "); 
        Input1 = input.nextInt();
        if (Input1 > 99 || Input1 < 0) {
        System.out.print("Outside Range. Program ending:");
        return;
        }}
        System.out.print("Next, please enter another integer between 0-99: ");
        Input2 = input.nextInt();
        if (Input2 > 99 || Input2 < 0) { 
        System.out.print("Outside Range. Please enter an integer between 0-99: "); 
        Input2 = input.nextInt();
        if (Input2 > 99 || Input2 < 0) {
        System.out.print("Outside Range. Program ending:");
        return;
        }}
        
        if (Input1 < Input2){
        Min = Input1;
        Max = Input2;
        }
        else {
        Min = Input2;
        Max = Input1;
        }
        
        Integer1 = Min + (int)(Math.random() * ((Max - Min) + 1));
        Integer2 = Min + (int)(Math.random() * ((Max - Min) + 1));
        Integer3 = Min + (int)(Math.random() * ((Max - Min) + 1));
        
        if  (Integer1 > Integer2) {
        Hold = Integer1;
        Integer1 = Integer2;
        Integer2 = Hold;
        }
        if (Integer2 > Integer3) {
        Hold = Integer2;
        Integer2 = Integer3;
        Integer3 = Hold;
                }
        
        if ( Integer1 > Integer2) {
        Hold = Integer1;
        Integer1 = Integer2;
        Integer2= Hold;        
            }
        System.out.println("The range begins at " +Min+ " ends at " +Max);
        System.out.println("Three sorted random integers between " +Min+ " and " +Max+" are:");
        
        if (Integer1 %2==0){
        System.out.println(Integer1+ " Even");
        }
        else {
        System.out.println(Integer1+ " Odd");
        }   
        if (Integer2 %2==0){
        System.out.println(Integer2+ " Even");
        }
        else {
        System.out.println(Integer2+ " Odd");
        }  
        if (Integer3 %2==0){
        System.out.println(Integer3+ " Even");
        }
        else {
        System.out.println(Integer3+ " Odd");
        } 
        double Int1 = (double) Integer1;
        double Int2 = (double) Integer2;
        double Int3 = (double) Integer3;
        double Quotient;
        double Quotient1;
        double Quotient2;
        Sum = Integer1+Integer2+Integer3;
        Product = Integer1*Integer2*Integer3;
        Quotient1 = Int1/Int2;
        Quotient2 = Quotient1/Int3;
        Quotient = Quotient2;
        System.out.println("\nSum = " +Sum);
        System.out.println("Product = " +Product);
        System.out.println("Quotient (Int1/Int2/Int3) = " +Quotient);
    }

   }
    

