/******************************************************************************
 * Program Name:          Lab04 - PayStub Calculations
 * Program Description:   This program calculates net paycheck information
 * Program Author:        Waiyat Hamdani
 * Date Created:         10/04/2016
 * Change#        Change Date      Programmer Name        Description
 * -------        ------------     -------------------    ---------------------
******************************************************************************/
package lab04waiyat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Scanner;
public class Lab04Waiyat {

    public static void main(String[] args) {
    Scanner input= new Scanner(System.in);
    NumberFormat numberFormat = new DecimalFormat("#,###.00");
    //final double *//
    final double SOC_SEC_RATE=0.06;
    final double MEDICARE_RATE=0.01;
    final double UNION_DUES_RATE=0.01;
    final double RETIREMENT_PLAN_RATE=0.02;
    final double RETIREMENT_HEALTH_RATE=0.03;
    
    // enter your input
     System.out.println("enter hour of work:");
     double hourWork = input.nextDouble();
     System.out.println("enter pay rate:$");
     double payRate = input.nextDouble();
     System.out.println("enter fed tax withb holding rate:$");
     double fedTaxWithHoldingRate = input.nextDouble();
     System.out.println("enter state tax with holding rate:$");
     double stateTaxWithHoldingRate = input.nextDouble();
     
      //output
    System.out.println("***********************");
    System.out.println("**PayStub Information**");
    System.out.println("***********************");
     
    //Equal solution 
    double grossPay;
    double fedTaxWithHeld;
    double stateTaxWithHeld;
    System.out.println("Hours Worked:"+numberFormat.format(hourWork));
    System.out.println("Pay Rate:$"+numberFormat.format(payRate));
    System.out.println("Gross Pay:$"+numberFormat.format(grossPay=hourWork*payRate));
    System.out.println("deductions:");
    System.out.println("\n\tFederal Tax(15.0%)"+numberFormat.format(fedTaxWithHeld=grossPay*fedTaxWithHoldingRate));
    System.out.println("\n\tState Tax(10.0%)"+numberFormat.format(stateTaxWithHeld=grossPay*stateTaxWithHoldingRate));
    double socsecTaxWithHeld;
    double medicareTaxWithHeld;
    double unionDuesWithHeld;
    double retirementPlanWithheld;
    double retirementHealthWithheld;
    System.out.println("\n\tSocial Security Tax(6.0%):" +numberFormat.format(socsecTaxWithHeld=grossPay*SOC_SEC_RATE));
    System.out.println("\n\tMedicare Tax(1.0%):" +numberFormat.format(medicareTaxWithHeld=grossPay*MEDICARE_RATE));
    System.out.println("\n\tUnion Dues(1.0%):" +numberFormat.format(unionDuesWithHeld=grossPay*UNION_DUES_RATE));
    System.out.println("\n\tRetirement Plan(2.0%)"+numberFormat.format(retirementPlanWithheld=grossPay*RETIREMENT_HEALTH_RATE));
    System.out.println("\n\tRetirement Health(3.0%)"+numberFormat.format(retirementHealthWithheld=grossPay*RETIREMENT_HEALTH_RATE));
     
    
    //Calculation or compute
    double totalDeductions;
    System.out.println("totalDeductions:"+(totalDeductions=fedTaxWithHeld+stateTaxWithHeld+socsecTaxWithHeld+
           medicareTaxWithHeld+unionDuesWithHeld+retirementPlanWithheld+retirementHealthWithheld ));

    System.out.println("netPay:"+(grossPay-totalDeductions));

   
    
    }
    
}


